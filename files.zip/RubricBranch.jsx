import { useState } from "react";
import "../styles/landing.css";

/**
 * RubricBranch — the branching screen the person lands on right after
 * submitting a document.
 *
 * Autodetect has already run; the detected rubric arrives preselected with
 * its criteria laid open. The other rubrics are selectable alternatives.
 * Confirm → analysis.
 *
 * Props:
 *   rubrics      array of rubric configs from rubrics/index.js
 *                expected shape (rendered defensively):
 *                { id, name, description?, stub?, tiers?, tolerance?: { ceilings, nearNullRank } }
 *   detectedId   id returned by autodetect
 *   onConfirm(rubricId)
 *   onBack()
 *
 * Branch colors match the mark's offshoot streams — the logo is the map.
 */

const BRANCH_COLORS = {
  corporate: "#3557A7",
  research: "#8C2F39",
  journalism: "#C58A17",
  general: "#2F6B4F",
};

export default function RubricBranch({ rubrics = [], detectedId, onConfirm, onBack }) {
  const [selected, setSelected] = useState(detectedId || rubrics[0]?.id);

  return (
    <main className="eh-branch">
      <header className="eh-branch-head">
        <button className="eh-backlink" onClick={onBack}>← Different document</button>
        <p className="eh-microlabel">Document read · rubric detected</p>
        <h1 className="eh-branch-title">Confirm the standard it will be held to</h1>
        <p className="eh-branch-sub">
          Every document is scored against one declared rubric, applied uniformly.
          Autodetect suggests one; you decide.
        </p>
      </header>

      <div className="eh-branch-grid" role="radiogroup" aria-label="Rubric">
        {rubrics.map((r) => {
          const color = BRANCH_COLORS[r.id] || "#17181A";
          const isSel = r.id === selected;
          const isDetected = r.id === detectedId;
          const ceilings = r.tolerance?.ceilings;
          const nearNull = r.tolerance?.nearNullRank;
          return (
            <button
              key={r.id}
              role="radio"
              aria-checked={isSel}
              className={`eh-rubric-card${isSel ? " is-selected" : ""}`}
              style={{ "--branch": color }}
              onClick={() => setSelected(r.id)}
            >
              <div className="eh-rubric-cardtop">
                <span className="eh-rubric-name">{r.name || r.id}</span>
                {isDetected && <span className="eh-tag eh-tag-detected">Detected</span>}
                {r.stub && <span className="eh-tag">Draft</span>}
              </div>

              {r.description && <p className="eh-rubric-desc">{r.description}</p>}

              <dl className="eh-rubric-criteria">
                {Array.isArray(ceilings) && (
                  <div>
                    <dt>Tolerance ceilings</dt>
                    <dd>{ceilings.join(" · ")}</dd>
                  </div>
                )}
                {typeof nearNull === "number" && (
                  <div>
                    <dt>Null-source rank</dt>
                    <dd>{nearNull} — unsourced assertions flagged loudest</dd>
                  </div>
                )}
                {r.tiers && (
                  <div>
                    <dt>Assertiveness tiers</dt>
                    <dd>{Object.keys(r.tiers).length ?? r.tiers.length} tiers</dd>
                  </div>
                )}
              </dl>
            </button>
          );
        })}
      </div>

      <div className="eh-branch-actions">
        <button
          className="eh-submit"
          disabled={!selected}
          onClick={() => onConfirm(selected)}
        >
          Run the analysis
        </button>
      </div>
    </main>
  );
}
